public class MojeDane {
    private String imie;
    private int wiek;

    public MojeDane(String imie, int wiek) {
        this.imie = imie;
        this.wiek = wiek;
    }

    public String getImie() {
        return imie;
    }

    public int getWiek() {
        return wiek;
    }

    public static void main(String[] args) {
        MojeDane mojeDane = new MojeDane("Mateusz", 20);
        System.out.println("Imię: " + mojeDane.getImie());
        System.out.println("Wiek: " + mojeDane.getWiek());
    }
}
