import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Podaj długość ciągu: ");
        int n = input.nextInt();
        int suma = 0;

        for (int i = 0; i < n; i++) {
            System.out.print("Podaj " + (i+1) + ". liczbę: ");
            int liczba = input.nextInt();

            if (liczba % 2 == 0) {
                suma += liczba;
            }
        }

        System.out.println("Suma liczb parzystych w ciągu: " + suma);

        input.close();
    }
}
