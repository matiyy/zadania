import java.util.Scanner;

public class Kalkulator {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Podaj pierwszą liczbę: ");
        double liczba1 = input.nextDouble();
        System.out.println("Podaj drugą liczbę: ");
        double liczba2 = input.nextDouble();

        obliczISpiszWyniki(liczba1, liczba2);
    }

    public static void obliczISpiszWyniki(double liczba1, double liczba2) {
        double suma = liczba1 + liczba2;
        double roznica = liczba1 - liczba2;
        double iloczyn = liczba1 * liczba2;

        System.out.println("Suma: " + suma);
        System.out.println("Różnica: " + roznica);
        System.out.println("Iloczyn: " + iloczyn);
    }
}
