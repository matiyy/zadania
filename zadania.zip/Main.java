import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Zadanie 1
        System.out.print("Podaj liczbę studentów: ");
        int n = input.nextInt();
        int sumaPunktow = 0;
        int i = 0;

        while (i < n) {
            System.out.print("Podaj punkty dla studenta nr " + (i+1) + ": ");
            sumaPunktow += input.nextInt();
            i++;
        }

        double srednia = (double) sumaPunktow / n;
        System.out.println("Średnia punktów w grupie: " + srednia);

        // Zadanie 2
        int iloscUjemnych = 0;
        int iloscDodatnich = 0;
        int sumaUjemnych = 0;
        int sumaDodatnich = 0;

        for (i = 0; i < 10; i++) {
            System.out.print("Podaj liczbę nr " + (i+1) + ": ");
            int liczba = input.nextInt();

            if (liczba < 0) {
                iloscUjemnych++;
                sumaUjemnych += liczba;
            } else {
                iloscDodatnich++;
                sumaDodatnich += liczba;
            }
        }

        System.out.println("Ilość liczb dodatnich: " + iloscDodatnich);
        System.out.println("Suma liczb dodatnich: " + sumaDodatnich);
        System.out.println("Ilość liczb ujemnych: " + iloscUjemnych);
        System.out.println("Suma liczb ujemnych: " + sumaUjemnych);

        input.close();
    }
}
