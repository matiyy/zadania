import java.util.Scanner;

public class Matematyka {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // przykładowe wywołanie trzech metod
        double liczba1 = 2.5;
        double wynik1 = potegaTrzecia(liczba1);
        System.out.println(liczba1 + " do potęgi trzeciej wynosi " + wynik1);

        double liczba2 = 9.0;
        double wynik2 = pierwiastekKwadratowy(liczba2);
        System.out.println("Pierwiastek kwadratowy z " + liczba2 + " wynosi " + wynik2);

        System.out.println("Podaj 3 liczby (od najmniejszej do największej): ");
        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();
        boolean wynik3 = czyTrojkatProstokatny(a, b, c);
        if (wynik3) {
            System.out.println("Z podanych odcinków można zbudować trójkąt prostokątny");
        } else {
            System.out.println("Z podanych odcinków nie można zbudować trójkąta prostokątnego");
        }
    }

    public static double potegaTrzecia(double liczba) {
        return Math.pow(liczba, 3);
    }

    public static double pierwiastekKwadratowy(double liczba) {
        return Math.sqrt(liczba);
    }

    public static boolean czyTrojkatProstokatny(double a, double b, double c) {
        if (a <= 0 || b <= 0 || c <= 0) {
            return false;
        }
        double max = Math.max(Math.max(a, b), c);
        if (max == a) {
            return Math.pow(a, 2) == Math.pow(b, 2) + Math.pow(c, 2);
        } else if (max == b) {
            return Math.pow(b, 2) == Math.pow(a, 2) + Math.pow(c, 2);
        } else {
            return Math.pow(c, 2) == Math.pow(a, 2) + Math.pow(b, 2);
        }
    }
}
