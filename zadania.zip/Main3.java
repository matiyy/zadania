import java.util.Scanner;

public class Main3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Zadanie 4
        System.out.print("Podaj ilość liczb do wylosowania: ");
        int n = input.nextInt();
        int suma = 0;

        for (int i = 0; i < n; i++) {
            int liczba = (int)(Math.random() * 56 - 10);

            if (liczba % 2 == 0) {
                suma += liczba;
            }
        }

        System.out.println("Suma liczb parzystych: " + suma);

        // Zadanie 5
        System.out.print("Podaj słowo: ");
        String slowo = input.next();

        boolean czyPalindrom = true;
        for (int i = 0; i < slowo.length() / 2; i++) {
            if (slowo.charAt(i) != slowo.charAt(slowo.length() - 1 - i)) {
                czyPalindrom = false;
                break;
            }
        }

        if (czyPalindrom) {
            System.out.println("Podane słowo jest palindromem.");
        } else {
            System.out.println("Podane słowo nie jest palindromem.");
        }

        input.close();
    }
}
